document.addEventListener("DOMContentLoaded", function() {
    const productos = [
        {nombre: "Camiseta", precio: 20000, imagen: "./img/camisa.jpg" },
        {nombre: "Pantalón", precio: 30000, imagen: "./img/pantalon.jpg" },
        {nombre: "Zapatos", precio: 50000, imagen: "./img/zapatos.jpg" },
        {nombre: "Bufanda", precio: 15000, imagen: "./img/bufanda" }
    ];

    const productosContainer = document.getElementById('productos');

    productos.forEach(producto => {
        const card = document.createElement("div");
        card.classList.add("producto");
        card.innerHTML = `
            <img src="${producto.imagen}" alt="${producto.nombre}">
            <h2>${producto.nombre}</h2>
            <p class="precio">$${producto.precio}</p>
            <button class="agregar-carrito">Agregar al carrito</button>
        `;
        productosContainer.appendChild(card);
    });
    // Manejar clic en botón "Agregar al carrito"
    productosContainer.addEventListener('click', function(event) {
        if (event.target.classList.contains('agregar-carrito')) {
            const nombreProducto = event.target.previousElementSibling.textContent;
            alert(`¡${nombreProducto} ha sido agregado al carrito!`);
            // Aquí podrías agregar lógica adicional para manejar la acción de agregar al carrito
        }
    });
});

